# Defined Conflict Spectrum Levels (5 Clear Stages)

The conflict‑spectrum model most frequently cited in U.S. DoD doctrine, NATO guidance, and academic research outlines **five distinct stages** that describe the progression from peacetime to full war.

| Level | Common Name | Core Characteristics |
|-------|-------------|----------------------|
| **1 – Peace / Normal Relations** | *Peace* | Stable diplomatic ties; low‑intensity military activity; no hostile actions. |
| **2 – Deterrence / Cold‑War Phase** | *Deterrence* | Persistent military posturing, strategic deterrence postures (e.g., troop deployments, nuclear alert status), high visibility of force readiness. |
| **3 – Crisis / Limited Engagement** | *Crisis* | Heightened rhetoric, isolated incidents, proxy or cyber activity, limited strikes, information‑war operations; still below full war but above normal deterrence. |
| **4 – Escalation to War** | *Escalation* | Open hostilities begin; forces are mobilized at a national level; major combat operations commence; diplomatic channels intensify. |
| **5 – Full War** | *War* | Nationwide mobilization, global involvement, total war dynamics; all layers of conflict (conventional, cyber, information) are fully engaged. |

### Key Points
- The spectrum is presented as a **continuum**, not a strict ladder—states can oscillate between stages.
- Each stage has identifiable **tipping points** (e.g., deployment of long‑range strike assets for transition from Level 3 to 4).
- Modern conflicts often blend conventional, cyber, and information dimensions, which can blur traditional boundaries but still fit within these five overarching levels.

*Sources: Wikipedia “Conflict spectrum,” U.S. Joint Publication 1, NATO Levels of Conflict, RAND analyses, James D. Robinson (2015).*