# Article Structure

**Title:** *Beyond the Rubric: Mapping the Iran–Israel Conflict Along the Spectrum — A Qualitative, Quantitative, and AI-Assisted Analysis*

**Author:** [Student Name], U.S. Naval War College

**Format:** Ten-page academic article

---

## Structural Overview

```
Page 1  – Title, Author, Abstract
Pages 1-2  – I. Introduction
Pages 2-3  – II. The Spectrum of Conflict: A Doctrinal Framework
Pages 3-5  – III. The Iran–Israel Case Study: From Proxy to Direct War
Pages 5-7  – IV. Qualitative and Quantitative Evaluation Methodology
Pages 7-8  – V. AI as an Analytical Tool: Five Models, One Conflict
Pages 8-9  – VI. Comparative Results and Interpretation
Pages 9-10 – VII. Limitations and Caveats
Page 10   – VIII. Conclusion
Page 10   – References
```

---

## I. Introduction (≈1 page)

**Hook:** The Iran–Israel conflict has undergone a fundamental transformation — from a decades-long shadow war of assassinations and proxy militias to open, state-on-state combat involving the United States, Arab Gulf states, and a widening geographic footprint.

**Problem statement:** Traditional conflict analysis relies on qualitative expert judgment that is difficult to replicate, scale, or audit. At the same time, purely quantitative metrics (troop counts, casualty figures) miss the strategic texture of escalation dynamics. How can we bridge these two approaches?

**Thesis:** This article argues that mapping the Iran–Israel conflict onto the U.S. doctrinal Spectrum of Conflict — using a hybrid qualitative-quantitative scoring rubric applied consistently across the timeline — provides a replicable framework for escalation analysis. Furthermore, comparing evaluations from five different AI models reveals both the promise and the pitfalls of using large language models as analytical assistants in strategic assessment.

**Roadmap:** The article proceeds as follows: Section II reviews the Spectrum of Conflict framework. Section III presents the Iran–Israel case study timeline. Section IV describes the hybrid scoring methodology. Section V discusses the multi-model AI experiment. Section VI compares results. Section VII addresses limitations. Section VIII concludes with implications for strategic analysis.

---

## II. The Spectrum of Conflict: A Doctrinal Framework (≈1 page)

**2.1 Origins and doctrinal basis**
- U.S. Joint Publication 1: the continuum from peace to war
- NATO AJP-01 levels of conflict
- Academic foundations (RAND, Robinson 2015)

**2.2 The five-level model**
- Level 1 Peace (0–20): stable diplomacy, routine posture
- Level 2 Deterrence (21–40): posturing, sanctions, show of force
- Level 3 Crisis (41–60): proxy conflict, covert action, cyber operations, limited strikes
- Level 4 Escalation (61–80): open hostilities, mobilization, direct state-on-state engagement
- Level 5 War (81–100): full-scale national mobilization, total war dynamics

**2.3 The spectrum as a heuristic**
- Not strictly linear; states can oscillate
- Hybrid warfare blurs traditional boundaries
- Value as a communication tool for policymakers and commanders

**2.4 Why it is suited for the Iran–Israel case**
- The conflict has traversed every level of the spectrum over five decades
- Clear tipping points are identifiable (e.g., April 2024 first direct strike)
- Multiple actors (state, proxy, non-state) map onto different levels simultaneously

---

## III. The Iran–Israel Case Study: From Proxy to Direct War (≈2 pages)

**3.1 Historical arc (1979–2026)**
- 1979–2005: revolution, severed ties, proxy emergence
- 2006–2023: Lebanon War, Stuxnet, Syrian civil war, covert operations
- 2024: the year direct confrontation began (consulate strike, April strikes, October strikes)
- June 2025: the Twelve-Day War
- February 2026–present: the Iran War

**3.2 Key inflection points**
- 1979 Iranian Revolution: diplomatic rupture, onset of deterrence
- 1985: formal start of proxy conflict
- 2010 Stuxnet: first major cyber-weapon used against nuclear infrastructure
- 2020 Soleimani assassination: U.S. direct strike on Iranian leadership
- 1 April 2024: consulate bombing — crossing the direct-attack threshold
- 13–14 April 2024: Iran's first direct strike on Israel
- 13 June 2025: Israel's surprise attack on Iranian nuclear facilities
- 28 February 2026: full-scale U.S.-Israeli war on Iran

**3.3 The challenge of scoring**
- How to assign a single number to events with multiple dimensions?
- Proxy attacks (Level 3) happening simultaneously with diplomatic engagement (Level 1)
- The spectrum as a reductionist tool: what is gained and what is lost?

---

## IV. Qualitative and Quantitative Evaluation Methodology (≈1.5 pages)

**4.1 The hybrid rubric**
- Five levels with defined score ranges (0–20, 21–40, etc.)
- Qualitative anchors at each level: core characteristics drawn from doctrine
- Quantitative precision: 0–100 scale allows granularity within levels

**4.2 Scoring criteria**
- Diplomatic posture (severed ties, negotiations, sanctions)
- Military activity (exercises, deployments, strikes, mobilization)
- Proxy vs. direct involvement (who is pulling the trigger)
- Geographic scope (localized vs. regional vs. global)
- Casualty and infrastructure damage indicators

**4.3 The scoring process**
- One analyst (or AI) reviews each timeline event
- Assigns a level based on qualitative characteristics
- Refines to a specific numeric score within that level's range
- Records date, score, and level in CSV format

**4.4 From qualitative to quantitative: what the numbers represent**
- A score of 15 (Peace) vs. 98 (War) captures not just intensity but also the nature of the interaction
- The numerical scale enables statistical comparison, trend analysis, and visual charting
- But the numbers are only as good as the qualitative judgment behind them

---

## V. AI as an Analytical Tool: Five Models, One Conflict (≈1.5 pages)

**5.1 Motivation**
- Human analysts are expensive, inconsistent, and unavailable at scale
- Can AI models provide rapid, reproducible baseline assessments?
- How much do different AI "analysts" agree with each other?

**5.2 Experimental design**
- Five large language models selected: Gemini, Claude, ChatGPT, GLM, Deepseek
- Each model given the same inputs:
  - Prompt 1: research the conflict and produce a timeline
  - Prompt 2: read the spectrum definitions and score each event
- No training or calibration across models
- Each model independently chose its own timeline dates and scores

**5.3 The Spectrum of Conflict rubric provided to all models**
- (Same five-level rubric from Section II)
- Score ranges defined; models used their own judgment within ranges

**5.4 What each model produced**
- Gemini: 18 events, 2023–2026 focus, broader score range (35–100)
- Claude: 25 events, 2023–2026, more granular in 2026 (20–95)
- ChatGPT: 16 events, 2025–2026 only, narrow window but dense coverage
- GLM: 14 events, 1979–2024 only (missing 2025–2026 entirely)
- Deepseek: 60 events, 1979–2026, most comprehensive historical coverage

**5.5 From individual CSVs to a merged dataset**
- All five Score.csv files combined into MixScore.csv
- 92 unique dates across the union
- Columns: Date, Gemini, Claude, ChatGPT, GLM, Deepseek
- Enables side-by-side visual comparison in Google Sheets

---

## VI. Comparative Results and Interpretation (≈1 page)

**6.1 Agreement across models**
- Where did all models converge? (e.g., June 2025 Twelve-Day War scored 84–95)
- Where did they diverge? (e.g., October 2024: Gemini 79, Claude 70, GLM 82, Deepseek 78)
- Post-MOU June 2026: Gemini 35, Claude 20, Deepseek 55 — wide spread

**6.2 Systematic biases observed**
- **Recency bias:** ChatGPT and Gemini focused heavily on 2025–2026
- **Historical depth:** Deepseek and GLM included pre-2023 events
- **Score clustering:** Claude clustered in the 40–70 range; Gemini used more extreme values
- **Level naming inconsistency:** "Level 3 - Crisis" vs. "Level 3 Crisis" vs. "Level 3 - Crisis" — minor but meaningful for data merging

**6.3 What the chart reveals**
- The conflict trajectory is unmistakable: a long plateau at Level 3 (Crisis) with sharp spikes at Level 5 (War)
- The transition from proxy (Level 3) to direct (Level 4) in 2024 is visible across all models that covered that period
- The 2026 Iran War shows sustained Level 5 across all contemporaneous models
- AI models that missed the early history produce an incomplete picture

**6.4 Implications for strategic analysis**
- AI can produce rapid, consistent baseline assessments — useful for initial estimates
- But models require human calibration, quality control, and historical context
- Multi-model ensembles may provide more robust assessments than any single model

---

## VII. Limitations and Caveats (≈1 page)

**7.1 The subjectivity problem**
- Scoring remains inherently subjective — the rubric provides structure but not objectivity
- Different analysts (human or AI) will interpret the same event differently
- The "true" score does not exist; the value is in the comparison

**7.2 AI limitations**
- Knowledge cutoffs: some models lacked information on post-training events
- Hallucination and fabrication of dates or events
- Inconsistent reasoning: models do not "think" but predict text
- Lack of deep strategic context: AI cannot understand operational art

**7.3 Methodological limitations**
- Single-axis scoring (0–100) collapses multidimensional conflict into one number
- Proxy and direct activities occur simultaneously at different levels
- The spectrum is a heuristic, not a predictive model
- Small sample size: five models, one conflict, one rubric

**7.4 Data quality**
- Wikipedia as primary source: generally reliable for facts but varies in completeness
- Date standardization: different models used different date formats
- Missing data: GLM's timeline ended in 2024, creating a gap

**7.5 Ethical considerations**
- AI should augment — not replace — human strategic judgment
- Risk of over-reliance on numerical scores in sensitive decisions
- Transparency: the rubric, prompts, and model outputs must be auditable

---

## VIII. Conclusion (≈0.5 page)

**Summary of findings:**
- The Spectrum of Conflict provides a useful framework for tracing the Iran–Israel escalation arc
- A hybrid qualitative-quantitative rubric enables replicable scoring across a 47-year timeline
- AI models can rapidly produce scored assessments, but with significant variation
- Multi-model comparison reveals both consensus zones and systematic biases

**Contribution:**
This article demonstrates a practical method for combining doctrinal frameworks, reproducible scoring, and AI-assisted analysis — producing a dataset that can be updated, challenged, and refined by other analysts.

**Recommendations for practice:**
- Use AI as a first-pass analytical assistant, not a final arbiter
- Always compare multiple models and multiple human analysts
- Maintain transparent rubrics and audit trails
- Keep the human in the loop for contextual judgment

**Final thought:**
The Iran–Israel conflict will continue to evolve, and so must our tools for understanding it. The spectrum, the score, and the assistant are all aids to strategic thinking — not substitutes for it.

---

## References

*(To be populated with APA-style citations from Reference.txt)*

---

## Appendices (optional, if page count allows)

- **Appendix A:** Full Timeline.md (included as abridged text)
- **Appendix B:** Score.csv (Deepseek scoring)
- **Appendix C:** MixScore.csv (multi-model data)
- **Appendix D:** Scoring rubric one-pager

---

*Article length estimate: ≈4,500–5,000 words (10 pages, double-spaced, 12pt Times New Roman, 1-inch margins)*
