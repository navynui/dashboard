# USA & Israel vs Iran — Conflict Timeline

> A comprehensive timeline of the proxy and direct conflict from its origins to the present (July 2026).

---

## 1979–1984: The Break

| Date | Event |
|------|-------|
| **1979** | Iranian Revolution overthrows the Shah. Ayatollah Khomeini declares Israel an "enemy of Islam." Iran severs all diplomatic, commercial, and military ties with Israel. |
| **1980–1988** | Iran–Iraq War. Despite severed ties, Israel secretly supplies weapons and military equipment to Iran. Israel also bombs and destroys Iraq's Osirak nuclear reactor (Operation Babylon, 1981), which helps Iran. |
| **1982** | Israel invades Lebanon. Lebanese Shia leaders appeal to Iran for help. Iran sends defense minister and trainers, laying groundwork for Hezbollah. |
| **1985** | Iran–Israel proxy conflict formally begins (16 Feb 1985). Iran funds, arms, and trains Hezbollah to fight Israeli forces in southern Lebanon. |

---

## 1985–2005: The Proxy Era

| Date | Event |
|------|-------|
| **1985–2000** | Hezbollah grows into a major military and political force in Lebanon with Iranian backing. Israel occupies southern Lebanon. |
| **2000** | Israel withdraws from southern Lebanon. Hezbollah takes over assets of the South Lebanon Army. Low-level conflict continues around the Shebaa Farms. |
| **2005** | Mahmoud Ahmadinejad elected president of Iran. Tensions with Israel escalate sharply. Iran begins funding Hamas more heavily. |

---

## 2006: The 2006 Lebanon War

| Date | Event |
|------|-------|
| **July–Aug 2006** | Hezbollah launches cross-border raid into Israel, triggering a 34-day war. Iranian Revolutionary Guards (IRGC) reportedly assist Hezbollah with rocket attacks and anti-ship missiles (damage INS *Hanit*). War ends in military stalemate; Israel withdraws. |

---

## 2007–2014: Sabotage, Cyberwar & Assassinations

| Date | Event |
|------|-------|
| **6 Sep 2007** | Israeli Air Force destroys a suspected Syrian nuclear reactor (Operation Outside the Box). |
| **2009** | Israel reportedly strikes Iranian arms convoys in Sudan. Mossad suspected of sabotage operations inside Iran. |
| **2010** | **Stuxnet worm** discovered — a US-Israeli cyberweapon that damages ~1,000 centrifuges at Iran's Natanz nuclear facility. |
| **2011** | Mossad suspected in explosion at Isfahan nuclear facility and a missile-base blast killing IRGC General Hassan Moqaddam. Iran retaliates via proxies. |
| **2012** | Bomb attacks on Israeli diplomats in India, Georgia, Thailand, and Bulgaria. Israel blames Iran and Hezbollah. |
| **2012** | Israel shoots down a Hezbollah drone over the Negev. |
| **2013–2017** | Israel carries out numerous airstrikes in Syria targeting Iranian weapons shipments to Hezbollah. |
| **2014** | Israel intercepts the *Klos-C* cargo ship carrying Iranian rockets to Gaza. |

---

## 2015–2023: Syrian Civil War & Covert Operations

| Date | Event |
|------|-------|
| **2015** | Iran and world powers sign the JCPOA (Iran nuclear deal). |
| **2017–2018** | Israel begins near-daily airstrikes against Iranian targets in Syria, dropping ~2,000 bombs in 2018 alone. |
| **Jan 2018** | Mossad steals 50,000 pages and 163 CDs of Iran's nuclear archives from a Tehran warehouse. |
| **2018** | Trump withdraws US from JCPOA; reimposes sanctions on Iran. |
| **2020** | US assassinates Qasem Soleimani in Baghdad (3 Jan). Iran retaliates with missile strikes on Al-Asad Airbase. |
| **2020** | Mohsen Fakhrizadeh, head of Iran's nuclear weapons program, assassinated near Tehran (27 Nov). |
| **2020–2021** | Series of explosions, fires, and cyberattacks hit Iranian nuclear, missile, and industrial sites. |
| **2021** | Attacks on Israeli-owned ships; Iran begins enriching uranium to 60% purity. |
| **2022–2023** | Iranian nuclear scientists assassinated; IRGC officers killed in Syria. |
| **2023 (Jan)** | Drone attack on Iranian defense factory in Isfahan — blamed on Israel. |

---

## 2023–2024: The Gaza War & Escalation

| Date | Event |
|------|-------|
| **7 Oct 2023** | Hamas-led attack on Israel kills ~1,200 Israelis. Israel launches the Gaza war. |
| **2023–2024** | Hezbollah, Houthis, and Iranian-backed militias attack Israel in solidarity with Hamas. |
| **25 Dec 2023** | Israel kills IRGC senior adviser Sayyed Razi Mousavi in Damascus. |
| **20 Jan 2024** | Israeli strike kills 5 IRGC officers in Damascus. |
| **1 Apr 2024** | **Israel bombs Iranian consulate in Damascus**, killing 16 including IRGC Quds Force commander Mohammad Reza Zahedi. |
| **13 Apr 2024** | Iran seizes Israeli-linked ship *MSC Aries* in the Strait of Hormuz. |
| **13–14 Apr 2024** | **Iran launches ~300 drones and missiles directly at Israel** — first direct Iranian attack on Israel. US, UK, France, Jordan help intercept. |
| **19 Apr 2024** | **Israel retaliates** with limited strikes near Isfahan, hitting a radar for Natanz nuclear site. Both sides signal de-escalation. |
| **31 Jul 2024** | **Ismail Haniyeh (Hamas leader) assassinated in Tehran** — hours after Fuad Shukr (Hezbollah commander) killed in Beirut. Both blamed on Israel. |
| **1 Oct 2024** | **Iran launches ~200 ballistic missiles at Israel** (Operation True Promise II). |
| **26 Oct 2024** | **Israel strikes military targets in Iran**, hitting missile and drone facilities. |

---

## 2025: The Twelve-Day War (June 13–24)

| Date | Event |
|------|-------|
| **12 Jun 2025** | IAEA declares Iran non-compliant with nuclear safeguards. |
| **13 Jun 2025** | **Israel launches a surprise attack on Iran** — the Twelve-Day War begins. Israel strikes nuclear facilities (Natanz, Isfahan, Fordow), kills IRGC leaders, nuclear scientists, and politicians. |
| **13–24 Jun 2025** | Iran retaliates with 550+ ballistic missiles and 1,000+ drones hitting Israeli civilian and military sites. |
| **22 Jun 2025** | **United States enters the war directly**, bombing three Iranian nuclear sites. Houthis declare US actions a "declaration of war." |
| **24 Jun 2025** | Ceasefire agreed under US pressure. Thousands killed; major damage to Iranian nuclear program. |

---

## 2026: The Iran War (Feb 28 – Present)

| Date | Event |
|------|-------|
| **28 Feb 2026** | **US and Israel launch massive strikes on Iran** — Operation Epic Fury / Operation Roaring Lion. **Supreme Leader Ali Khamenei is assassinated** along with thousands of IRGC personnel. |
| **28 Feb – Mar 2026** | Iran retaliates with missiles and drones against Israel, US bases, and Arab allies (Saudi Arabia, UAE, Bahrain, Kuwait, Qatar). Iran closes the Strait of Hormuz. |
| **3 Mar 2026** | Israel authorizes ground invasion of southern Lebanon. Hezbollah re-enters the conflict. |
| **4 Mar 2026** | Iranian frigate IRIS *Dena* sunk by US submarine USS *Charlotte* in the Indian Ocean. |
| **8 Mar 2026** | Mojtaba Khamenei elected as Iran's new Supreme Leader. |
| **17 Mar 2026** | Senior Iranian official Ali Larijani assassinated by Israel. Iran launches cluster-munition missile barrages on Israel. |
| **22 Mar 2026** | Houthis join the war, launching ballistic missiles at Israel. |
| **27 Mar 2026** | Iran strikes Prince Sultan Air Base in Saudi Arabia, damaging US aircraft. |
| **28 Mar 2026** | US strikes over 11,000 targets in Iran since war began. Iran threatens to seize Gulf territory. |
| **8 Apr 2026** | Two-week ceasefire begins; strain over Lebanon. |
| **12–13 Apr 2026** | Islamabad Talks between US and Iran fail. |
| **13 Apr 2026** | US imposes naval blockade on Iran. Iran maintains its own blockade of the Strait of Hormuz ("dual blockade"). |
| **Late May 2026** | US estimates $113.3B spent on war so far. |
| **14 Jun 2026** | US and Iran reach draft agreement to end war. |
| **17 Jun 2026** | **Memorandum of Understanding signed** at Palace of Versailles — 60-day suspension of hostilities. US makes major concessions; Iran retains missile/drone arsenal. |
| **8 Jul 2026** | **Ceasefire collapses** after both sides resume attacks. US strikes ~90 Iranian military targets. Iran re-closes Strait of Hormuz. |
| **10 Jul 2026** | Israel provides intelligence on alleged Iranian plot to assassinate Trump. |
| **13–20 Jul 2026** | Renewed hostilities: US reinstates naval blockade, Iran strikes US bases in Kuwait, Jordan, Bahrain. Heavy casualties on both sides. Two US soldiers killed in Jordan. |
| **20 Jul 2026** | Iran claims surprise attack on US command center in Syria. CENTCOM continues strikes "to degrade Iranian capabilities." War ongoing. |

---

## Key Observations

- **Proxy conflict (1985–2024):** Iran armed Hezbollah, Hamas, Houthis, and Iraqi militias to fight Israel by proxy. Israel conducted covert operations, assassinations, and cyberattacks against Iran.
- **Direct confrontation (2024):** For the first time, Iran and Israel struck each other's territory directly in April and October 2024.
- **Twelve-Day War (Jun 2025):** A brief but intense direct war, with the US joining on Israel's side.
- **2026 Iran War (Feb 2026 – Present):** Full-scale war between the US-Israel alliance and Iran. The conflict has caused tens of thousands of casualties, massive infrastructure damage, a global energy crisis, and the collapse/revival of ceasefire agreements. As of late July 2026, the war continues with no permanent resolution.

---

*Sources: Wikipedia (Iran–Israel proxy conflict, 2024 Iran–Israel conflict, Twelve-Day War, 2026 Iran war). Last updated: July 2026.*
