# Procedure: Conflict Timeline → Score → Multi-Model Mix

This document explains the step-by-step procedure used to go from two text prompts to the final deliverables — a conflict timeline, scored CSV data, and a combined multi-model CSV for comparative charting.

---

## Overview

```
Prompt1.txt ──→ Research online ──→ Timeline.md
                                            │
Prompt2.txt ──→ Read Defined5Levels.md ────┤
                 Read Spectrum.md ─────────┤
                 Assign scores/levels ─────→ Score.csv
                                            │
              Collect Score.csv from ───────┤
              Gemini, Claude, ChatGPT,      │
              GLM, Deepseek                 │
                                            ├──→ MixScore.csv
                                            └──→ Reference.txt
```

---

## Step 1 — Research & Create the Timeline

**Input:** `Prompt1.txt` (contains instruction to research the USA/Israel vs Iran conflict)

**What to do:**

1. Read the prompt file:
   ```
   read ../Prompt1.txt
   ```

2. Research the conflict online. Useful sources:
   - Wikipedia API: `https://en.wikipedia.org/api/rest_v1/page/summary/<page_title>`
   - Full article extracts via: `https://en.wikipedia.org/w/api.php?action=query&titles=<title>&prop=extracts&explaintext&format=json`

3. Key Wikipedia articles to query:
   - `Iran–Israel_proxy_conflict` — the full proxy conflict since 1985
   - `2024_Iran–Israel_conflict` — the April–October 2024 escalation
   - `Twelve-Day_War` — the June 2025 war
   - `2026_Iran_war` — the February 2026 onward full-scale war

4. Compile the information into a chronological markdown file with:
   - Section headers by era (e.g., `## 1979–1984: The Break`)
   - A table per section with columns: **Date** | **Event**
   - Bold key events for emphasis
   - A summary of key observations at the end

5. **Output:** `Timeline.md`

---

## Step 2 — Define the Scoring Rubric

**Input:** `Prompt2.txt`

**What to do:**

1. Read the two definition files:
   ```
   read ../Defined5Levels.md
   read ../Spectrum.md
   ```

2. From these, extract the **5-level conflict spectrum**:

| Level | Name | Score Range |
|-------|------|-------------|
| 1 | Peace | 0–20 |
| 2 | Deterrence | 21–40 |
| 3 | Crisis | 41–60 |
| 4 | Escalation | 61–80 |
| 5 | War | 81–100 |

3. Use the core characteristics from each level to evaluate events:

| Level | Characteristics to look for |
|-------|---------------------------|
| **Peace** | Stable diplomatic ties, no hostile actions, routine exercises |
| **Deterrence** | Military posturing, threat displays, sanctions, show of force |
| **Crisis** | Proxy attacks, covert ops, cyberwarfare, limited strikes, hostile rhetoric |
| **Escalation** | Open military hostilities, mobilization, direct state-on-state strikes |
| **War** | Full-scale war, nationwide mobilization, global involvement, total war dynamics |

---

## Step 3 — Score Every Timeline Entry

**What to do:**

1. Go through each row in `Timeline.md` one by one.

2. For each entry, ask:
   - What level of conflict does this event represent based on the rubric?
   - What specific score (within that level's range) fits the severity?

3. Scoring guidance within each level:
   - **Peace (0–20):** 0 = total peace/allies, 10 = neutral but cool, 20 = tense but still diplomatic
   - **Deterrence (21–40):** 21 = mild posturing, 30 = active sanctions/threats, 40 = brinkmanship
   - **Crisis (41–60):** 41 = isolated incident, 50 = sustained proxy conflict, 60 = near-escalation
   - **Escalation (61–80):** 61 = limited strikes, 70 = open but localized war, 80 = nearing total war
   - **War (81–100):** 81 = war declared, 90 = intense combat, 100 = apocalyptic/extreme

4. **Output format:** CSV with 3 columns

   ```
   Date,Conflict Score,Level of Conflict
   1979-01-01,25,Level 2 Deterrence
   ...
   ```

5. Use ISO date format (`YYYY-MM-DD`) for Google Sheets compatibility. Use exact dates where available; use the 1st of the month or a representative date for year/month-only entries.

6. **Output:** `Score.csv`

---

## Step 4 — Gather Multi-Model Scores

This step is for comparing how different AI models scored the same conflict.

**What to do:**

1. Locate the `Score.csv` files from other AI model runs in sister directories:
   ```
   ../Gemini/Score.csv
   ../Claude/Score.csv
   ../ChatGPT/Score.csv
   ../ZAI-GLM5.2/Score.csv
   ```

2. Read each one to understand its date range, column format, and scoring choices.

3. Merge them into a single CSV with one shared date column and one score column per model:

   | Date | Gemini | Claude | ChatGPT | GLM | Deepseek |
   |------|--------|--------|---------|-----|----------|
   | ...  | (score)| (score)| (score) | (score) | (score) |

4. Implementation approach (Python):
   ```python
   # Collect all unique dates from all files
   # For each date, look up each model's score
   # Leave blank if a model has no entry for that date
   ```

5. **Output:** `MixScore.csv`

---

## Step 5 — Write References

**What to do:**

1. List all sources used for the timeline facts.
2. Format them in APA 7th edition style.
3. For Wikipedia articles, use:
   ```
   Title. (Year). In Wikipedia. Retrieved Date, from URL
   ```
4. For doctrinal sources (joint publications, NATO standards), use standard APA book/report format.
5. **Output:** `Reference.txt`

---

## File Summary

| File | Description |
|------|-------------|
| `Timeline.md` | Chronological conflict history with date-event tables |
| `Score.csv` | Single-model scored data: Date, Score, Level |
| `MixScore.csv` | Multi-model merged scores for comparative line chart |
| `Reference.txt` | APA-style source citations |

---

## Tips for Google Sheets Charting

**For Score.csv (single line):**
```
Date       | Conflict Score
1979-01-01 | 25
...
```
→ Insert chart → Line chart → X-axis: Date, Series: Conflict Score

**For MixScore.csv (multi-line):**
```
Date       | Gemini | Claude | ChatGPT | GLM | Deepseek
1979-01-01 |        |        |         |     | 25
...
```
→ Insert chart → Line chart → X-axis: Date, Series: Gemini, Claude, ChatGPT, GLM, Deepseek
→ Each model gets its own colored line → Gaps where a model has no data for that date

---

## Notes

- Dates must use consistent `YYYY-MM-DD` format for Google Sheets to recognize them as dates.
- Empty cells in MixScore.csv will appear as gaps in the line — this is normal and expected.
- Different AI models may choose different dates for their timeline entries, so the lines will not align at every point. The chart shows each model's independent trajectory.
- The scoring rubric is inherently subjective; different scorers may assign different levels to the same event. The purpose of MixScore.csv is to visualize and compare those differences.
