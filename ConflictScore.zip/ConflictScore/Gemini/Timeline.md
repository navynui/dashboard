# Timeline Summary: USA-Israel vs. Iran Conflict (2023–2026)

The long-standing proxy war between the United States, Israel, and Iran shifted from a "shadow war" into direct, devastating state-on-state military conflicts. 

---

## 1. The Proxy Era Shifts to Direct Conflict (2023–2024)

For decades, the conflict was fought via Iran's "Axis of Resistance" (Hamas, Hezbollah, and the Houthis). The regional landscape completely shifted following the October 7, 2023, Hamas attacks on Israel. 

* **April 1, 2024:** Israel bombs the Iranian consulate in Damascus, Syria, killing high-ranking Islamic Revolutionary Guard Corps (IRGC) generals.
* **April 14, 2024:** In its first-ever direct assault from Iranian soil, Iran launches over 300 drones and missiles at Israel. Most are intercepted by Israel, the US, and regional allies. Israel responds with a calibrated counter-strike on an air defense system in Isfahan.
* **July–September 2024:** Israel assassinates Hamas leader Ismail Haniyeh in Tehran and Hezbollah leader Hassan Nasrallah in Beirut. 
* **October 2024:** Iran retaliates with a second massive ballistic missile barrage against Israel. Weeks later, on October 26, Israel openly retaliates by launching targeted airstrikes against Iran's missile production sites and air defenses.

---

## 2. The "Twelve-Day War" & US Entry (June 2025)

After months of failed diplomacy and escalating Iranian nuclear enrichment, the dynamic changed from a strictly regional conflict to direct American offensive involvement.

* **June 13–24, 2025:** Israel triggers a surprise aerial campaign against Iran’s primary nuclear and military facilities. 
* **June 22, 2025:** Marking a major policy shift, the United States joins the offensive operations. President Donald Trump deploys US B-2 stealth bombers and naval cruise missiles to strike three heavily fortified Iranian nuclear sites.
* **June 24, 2025:** Following significant infrastructure damage on both sides, the US and Israel enter a brief, fragile ceasefire with Iran. 

---

## 3. Coordinated Airstrikes & Regime Transition (Early 2026)

The collapse of interim diplomatic tracks in early 2026 caused a severe return to full-scale warfare.

* **February 28, 2026:** The US and Israel launch massive, highly synchronized air operations—headlined as Israel's *Operation Roaring Lion* and the US's *Operation Epic Fury*. Nearly 900 airstrikes are conducted in under 12 hours, targeting command structures, missile storehouses, and nuclear facilities. 
* **The Demise of Khamenei:** The opening strikes kill Iran's Supreme Leader Ayatollah Ali Khamenei alongside dozens of senior military commanders. In March, Iran formalizes a transition of power, naming his son, Mojtaba Khamenei, as the new paramount leader.
* **Regional Fallout & Ceasefire:** Iran retaliates by targeting US regional hubs and shutting the vital Strait of Hormuz trading route, triggering global energy panics. By April 8, 2026, Pakistan successfully brokers a tentative ceasefire between the US and Iran to pause the air campaign and temporarily restore shipping lanes.

---

## 4. Current Status: Maritime Blockades & Ongoing Attrition (Mid-2026)

The spring ceasefire proved short-lived as underlying geopolitical differences remained unresolved.

* **June 11–14, 2026 | The Pakistan Framework & Breakdowns:** High-level diplomatic delegations fail to find terms on the complete reopening of the Strait of Hormuz and frozen financial assets. Iran shuts down the Strait again. Trump warns of severe actions as the US and Iran exchange localized missile strikes.
* **June 17–20, 2026 | Brief Interim Agreements:** An interim 60-day cessation of hostilities is signed via mediators. However, alleging Israeli ceasefire violations and a renewed offensive push in Lebanon, Iran explicitly terminates the deal and blocks shipping channels once more.
* **July 7–15, 2026 | US Naval Blockade & Direct Strikes:** Following Iranian drone attacks on international vessels, the US deploys a major naval counter-blockade targeting all ships trying to access Iranian ports. Coordinated US airstrikes kill dozens of military targets within Iran.
* **July 18–19, 2026 | Active Hostilities & US Casualties:** Current intelligence confirms the theater remains hot. Recent Iranian retaliatory strikes on American regional positions killed two US service members, further entrenching the military gridlock.

---

## Analyst Assessment
Military and intelligence analysts observe that while the massive joint US-Israeli air campaigns have successfully degraded Iran’s forward-facing nuclear progress and conventional air defense capabilities, they have created deep systemic instability. Iran continues to leverage localized asymmetric capabilities—such as drone strikes on global shipping and regional rocket attacks—to keep the US and Israel locked in an ongoing war of attrition with no immediate political resolution in sight.
