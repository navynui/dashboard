Here is the timeline formatted in Markdown. You can copy the text inside the code block below and save it directly as a `.md` file.

```markdown
# Timeline: The USA, Israel, and Iran Conflict

The conflict involving the United States, Israel, and Iran is not a traditional declared war, but rather a multi-decade "shadow war" that recently escalated into direct military confrontations. Below is a timeline of the conflict’s evolution and a summary of current analyst consensus.

---

## Historical Context (Pre-2023): The "Shadow War"

* **1979:** The Iranian Revolution overthrows the US-backed Shah. The subsequent US Embassy hostage crisis severs diplomatic ties, beginning the modern US-Iran conflict.
* **1980s–2020s:** Israel and Iran engage in a "shadow war." Iran develops the "Axis of Resistance," a network of proxy groups (Hezbollah in Lebanon, Hamas in Gaza, the Houthis in Yemen, and various militias in Iraq and Syria). Israel routinely conducts airstrikes in Syria to disrupt Iranian weapons transfers. The US largely supports Israel logistically and diplomatically while imposing heavy sanctions on Iran.

---

## Timeline of Recent Escalation (October 2023 – Present)

### October 2023 – March 2024: Regional Ignition
* **October 7, 2023:** Hamas, backed by Iran, launches a massive attack on southern Israel. Israel responds with a heavy military campaign in Gaza.
* **October 2023 – onward:** The US deploys carrier strike groups to the Eastern Mediterranean to deter Iran and its proxies from opening a second front.
* **Proxy Attacks:** Hezbollah begins daily rocket fire into northern Israel, displacing tens of thousands of Israelis. Houthis begin attacking commercial shipping in the Red Sea, prompting US and UK airstrikes against Houthi targets.

### April 2024: The First Direct Exchange
* **April 1:** Israel conducts an airstrike on the Iranian consulate compound in Damascus, Syria, killing several high-ranking Islamic Revolutionary Guard Corps (IRGC) commanders.
* **April 13–14:** Iran responds by launching its first-ever direct military attack on Israel, firing over 300 drones, cruise missiles, and ballistic missiles. The US, UK, France, and regional allies help Israel intercept approximately 99% of the projectiles.
* **April 19:** Israel conducts a limited retaliatory strike near Isfahan, Iran, targeting an air defense radar. Both sides subsequently signal a desire to step back from all-out war, re-establishing the "shadow war" status quo.

### July – August 2024: High-Profile Assassinations
* **July 31:** Hamas political leader Ismail Haniyeh is assassinated by a bomb in a Tehran guesthouse shortly after attending Iran’s presidential inauguration. Iran attributes the assassination to Israel and vows severe retaliation.
* **August:** The US surges military assets to the region to brace for an Iranian response. Backchannel diplomacy (often mediated by European and Arab nations) works to keep Iran’s retaliation proportional to avoid regional war.

### September – October 2024: The Lebanon Escalation and Second Direct Strike
* **Mid-September:** Israel shifts its military focus from Gaza to Lebanon, conducting a massive pager/radio attack against Hezbollah, followed by heavy airstrikes that kill Hezbollah Secretary-General Hassan Nasrallah and much of his senior command. Iran condemns the attacks but does not immediately retaliate.
* **October 1:** Iran launches its second direct ballistic missile attack on Israel, firing roughly 180 missiles in retaliation for the deaths of Haniyeh, Nasrallah, and IRGC commander Abbas Nilforoushan.
* **October 26:** Israel conducts significant airstrikes on Iranian military facilities, targeting air defense systems and missile production capabilities. The US coordinates closely with Israel to ensure the strikes do not hit Iran's nuclear or oil facilities, aiming to contain the conflict.

### November – December 2024: Shifts in the Conflict
* **November:** Following the US presidential election, shifts in diplomatic strategy occur. A ceasefire is brokered in Lebanon between Israel and Hezbollah (mediated by the US and France), though violations are reported.
* **Current:** The direct Israel-Iran tit-for-tat pauses temporarily, but analysts note the underlying issues—Iran's nuclear program, its proxy network, and Israel's security concerns—remain unresolved. The US continues to deploy naval assets to defend Israel and shipping lanes from sporadic Houthi and Iraqi militia attacks.

---

## What News Analysts and Geopolitical Experts are Saying

Based on analyses from major think tanks (like the Institute for the Study of War) and international relations experts, several key consensus points have emerged:

1. **The End of the "Shadow War":** Analysts note that the strategic ambiguity that defined the Israel-Iran conflict for decades is gone. Both sides have now directly attacked each other's sovereign territory. The "red lines" have been fundamentally redrawn, making future direct strikes more likely.
2. **US Diplomatic and Military Tightrope:** Experts highlight that the US is caught in a complex balancing act. The Biden administration has provided unprecedented defensive military support to Israel (shooting down Iranian missiles) while simultaneously pressuring Israel to limit its retaliatory strikes to avoid triggering a broader regional war that would draw US troops into direct combat with Iran.
3. **Iran's Strategic Calculus:** Analysts point out that Iran’s direct strikes on Israel were largely symbolic and designed for domestic consumption and restoring deterrence, as they caused minimal damage. However, Israel’s systematic dismantling of Hezbollah’s leadership in Lebanon has severely degraded Iran's primary forward-defense proxy, leaving Iran more exposed.
4. **Nuclear Ambiguity:** Following the direct exchanges, some hardline analysts in both Israel and Iran have argued that the current conflict proves Iran needs a nuclear weapon to establish true deterrence against Israel, while others argue the conventional exchanges show deterrence still holds.
5. **Economic and Global Impact:** Defense and economic analysts warn that any future Israeli strikes on Iranian oil infrastructure or Iranian strikes on Gulf state oil facilities would cause massive global economic shocks, potentially pushing the US to intervene more forcefully to secure global energy markets.
```
