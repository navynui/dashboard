```markdown
# U.S./Israel–Iran Conflict Timeline (2023–2026)

## Background (2023–2024)
- **Oct 7, 2023** – Hamas attack on Israel triggers the broader Middle East crisis, pulling in Iran's regional proxy network (Hezbollah, Houthis, Iraqi militias).
- **April 2024** – Israeli strike on Iranian consulate annex in Damascus kills two Iranian generals. Iran responds with 300+ drones/missiles at Israel — its first-ever direct strike on Israeli territory.
- **Oct 2024** – After Israel kills Hamas leader Yahya Sinwar and Hezbollah leader Hassan Nasrallah, Iran launches 180 ballistic missiles at Israel. Israel responds with its largest-ever direct strike on Iran, hitting air defenses and missile production sites.

## June 2025 — The "12-Day War"
- **June 13, 2025** – Israel launches a major operation against Iran, striking nuclear facilities, military sites, and regime infrastructure.
- **June 13–20** – Iran counters with near-nightly missile barrages on Israel, killing dozens of civilians.
- **June 21, 2025** – The United States joins the fight, striking three Iranian nuclear sites: Fordow, Natanz, and Esfahan.
- **June 24, 2025** – US-brokered ceasefire begins (Iran halts first, Israel 12 hours later) after a rocky start with mutual accusations of violations. No formal peace agreement follows.

## Early 2026 — Renewed Collapse
- **Jan 2026** – Iranian security forces kill thousands of civilians while crushing the largest domestic protests since 1979.
- **Feb 2026** – Oman-mediated nuclear talks fail; Trump says he's "not thrilled" despite reported Iranian willingness to make concessions.

## Feb 28, 2026 — War Resumes ("Operation Epic Fury")
- US and Israel launch surprise coordinated airstrikes on Iran, hitting military/government sites and **assassinating Supreme Leader Ali Khamenei** and other officials.
- Iran retaliates against US bases, Israel, and regional sites, and **closes the Strait of Hormuz**.
- Hezbollah attacks Israel from Lebanon; Israel launches ground operations there.

## March–April 2026 — The Hormuz Crisis and First Ceasefire
- **Mid-March 2026** – US destroys 16 Iranian mine-laying vessels; continues strikes on Iranian ballistic missile and drone infrastructure.
- **April 13, 2026** – US imposes a naval blockade on Iran after Islamabad talks fail.
- **April 7–8, 2026** – After five+ weeks of fighting, US and Iran agree to a ceasefire that includes Israel.
- **Hours later** – Israel strikes Lebanon in a blitz killing hundreds, straining the truce.
- **April 16, 2026** – US pushes Israel to negotiate; a 10-day Israel-Hezbollah ceasefire is announced.

## May–June 2026 — Brinkmanship, Then a Deal
- **May 5, 2026** – Operation Epic Fury formally concludes.
- **May 29, 2026** – US naval blockade of Iran lifted.
- **June 14, 2026** – Mediators announce a 14-point memorandum of understanding (MoU) meant to end the conflict within 60 days.
- **June 17, 2026** – MoU signed by the US and Iranian presidents. Terms reportedly cover Iran's nuclear program, ballistic missiles, restricted sanctions relief (food/medicine only), and reopening Hormuz — though control of the strait is left ambiguous.

## July 2026 — Ceasefire Unravels (Current Situation)
- **July 6–7, 2026** – Iran fires on three commercial vessels in the Strait of Hormuz, triggering fresh US-Iran strikes and a sharp drop in strait traffic.
- **July 10, 2026** – Trump declares the ceasefire "over" but says the US will continue talks. Iran's negotiator says Tehran remains "distrustful of the Americans."
- **Mid-July 2026** – Ali Khamenei is buried; his son and successor, new Supreme Leader **Mojtaba Khamenei**, is notably absent from the funeral. He later says "revenge is the will of the nation."
- **July 15, 2026** – US carries out a fifth straight day of strikes, hitting Iranian command centers, air defenses, and coastal surveillance sites (including Bandar Abbas and Greater Tunb Island) to protect Hormuz shipping. Iran separately releases an American woman detained since Dec 2024.
- **July 18, 2026** – An Iranian drone hits a cargo ship in the strait, just a week after the preliminary deal was signed. Both sides exchange strikes on infrastructure and military targets. Pakistan and Qatar work behind the scenes to restart negotiations.

---

**Bottom line (as of July 19, 2026):** The conflict has passed through two major war phases (June 2025's 12-Day War and the Feb 2026 war that killed Khamenei), a rocky spring ceasefire process, and a June MoU meant to end things. That truce is now breaking down again over control of the Strait of Hormuz, with active strikes ongoing and mediators trying to prevent a full relapse into war.

*Note: This is a fast-moving situation — check a live tracker (Reuters, AP, Al Jazeera) for the latest developments beyond this timeline.*
```
