# USA–Israel vs Iran Conflict Timeline (June 2025 – July 2026)

**Last Updated:** 19 July 2026

> **Note:** This timeline focuses on the direct military conflict between Israel, Iran, and the United States. It does not cover the full decades-long proxy conflict between Israel and Iran.

---

# Background (Before June 2025)

For years, tensions steadily escalated through:

- Iran's nuclear program
- Israeli covert operations against Iranian nuclear facilities
- Assassinations of Iranian nuclear scientists
- Iranian support for Hezbollah, Hamas, Iraqi militias, and the Houthis
- Direct missile exchanges during 2024
- Increasing U.S. military deployments throughout the Persian Gulf

By early 2025, many security analysts believed the region was approaching direct war.

---

# 13 June 2025 — Israel Launches Operation Rising Lion

Israel launched a surprise large-scale military operation against Iran.

### Primary Targets

- Nuclear enrichment facilities
- IRGC command centers
- Ballistic missile infrastructure
- Military leadership
- Nuclear scientists

### Israeli Objectives

- Degrade Iran's nuclear program
- Reduce Iran's ballistic missile capability
- Eliminate senior IRGC leadership
- Restore strategic deterrence

Several senior Iranian commanders and nuclear scientists were reportedly killed.

---

# 13–24 June 2025 — Iran Retaliates

Iran launched one of the largest missile attacks in its history.

### Iranian Response

- Hundreds of ballistic missiles
- Large drone attacks
- Missile strikes against Israeli cities
- Military infrastructure attacks

Israel's air defense systems intercepted many incoming missiles, although several struck populated areas, causing civilian casualties and infrastructure damage.

---

# 21 June 2025 — United States Joins the Conflict

The United States conducted direct strikes against major Iranian nuclear facilities.

### Targeted Sites

- Fordow
- Natanz
- Isfahan

Washington described the strikes as limited operations intended to significantly damage Iran's nuclear infrastructure rather than pursue regime change.

Iran declared that the United States had officially entered the war.

---

# 23 June 2025 — Iran Retaliates Against U.S.

Iran launched missiles toward U.S. military installations.

### Main Target

- Al Udeid Air Base (Qatar)

Most incoming missiles were intercepted.

This marked one of the largest direct Iranian attacks against U.S. forces in decades.

---

# Late June 2025 — Ceasefire

International mediation helped end what became known as the **Twelve-Day War**.

However, the ceasefire was fragile.

### Situation After the Ceasefire

- No permanent peace agreement
- Iran continued rebuilding missile forces
- Israel continued intelligence operations
- U.S. military presence remained elevated
- Sanctions remained in place

Most analysts viewed this as a pause rather than the end of the conflict.

---

# Late 2025 — Renewed Diplomacy

Negotiations over Iran's nuclear program resumed intermittently.

Meanwhile:

- Iran accelerated missile production.
- Israel warned additional strikes remained possible.
- U.S. forces expanded regional deployments.
- Proxy attacks continued across the Middle East.

Diplomacy struggled while military preparations continued.

---

# Early 2026

Several developments increased tensions:

- Economic pressure inside Iran worsened.
- Domestic protests increased.
- International sanctions intensified.
- Nuclear negotiations ultimately collapsed.

Most analysts concluded that another military confrontation had become increasingly likely.

---

# 28 February 2026 — Major Escalation

Following the collapse of negotiations, the United States and Israel launched another coordinated military campaign.

### Reported Targets

- Military headquarters
- Missile infrastructure
- Government facilities
- Nuclear-related sites

### Iranian Response

Iran launched:

- Ballistic missiles
- Drone attacks
- Attacks against Israeli territory
- Attacks against U.S. military bases
- Threats against shipping in the Persian Gulf and Strait of Hormuz

---

# March–April 2026

The conflict expanded across the region.

### Iran

- Increased missile attacks
- Targeted U.S. regional partners
- Threatened maritime traffic

### United States & Israel

- Continued sustained air campaigns
- Expanded strikes against military infrastructure

A temporary ceasefire was later announced but remained fragile.

---

# June–July 2026 — Ceasefire Collapses

The ceasefire eventually failed.

Recent developments include:

- Renewed U.S. airstrikes
- Iranian missile attacks on U.S. regional bases
- Attacks affecting Kuwait, Bahrain, Jordan, and nearby areas
- Severe disruption around the Strait of Hormuz
- Rising global energy concerns
- Increasing civilian casualties

The conflict once again became an active regional war.

---

# Current Situation (19 July 2026)

As of today:

- Active fighting continues.
- The United States continues conducting air operations.
- Iran continues missile and drone attacks.
- Maritime security in the Persian Gulf remains unstable.
- Diplomatic negotiations have largely stalled.
- Global energy markets remain highly sensitive due to the Strait of Hormuz.

---

# Strategic Assessment

## Israel

Current objectives appear to be:

- Prevent Iran from acquiring nuclear weapons
- Reduce Iranian missile capabilities
- Weaken the IRGC
- Maintain long-term regional military superiority

---

## Iran

Current objectives appear to be:

- Preserve regime survival
- Maintain deterrence
- Demonstrate retaliatory capability
- Increase the cost of continued Israeli and U.S. military operations

---

## United States

Current objectives appear to be:

- Protect regional military assets
- Defend freedom of navigation
- Prevent Iranian nuclear weapon development
- Avoid a prolonged large-scale ground war

---

# What Most Analysts Agree On

## 1. No Side Wants a Ground Invasion

The conflict is primarily being fought through:

- Air power
- Missiles
- Drones
- Cyber operations
- Intelligence operations
- Regional proxy groups

A conventional invasion of Iran remains unlikely.

---

## 2. Iran Still Possesses Significant Military Capability

Despite substantial damage, Iran retains:

- Large ballistic missile stockpiles
- Extensive drone production
- Regional proxy networks
- Maritime disruption capabilities

---

## 3. Israel Seeks Long-Term Military Degradation

Israeli strategy appears focused on:

- Destroying nuclear infrastructure
- Reducing missile inventories
- Weakening Iran's regional influence

rather than occupying Iranian territory.

---

## 4. The U.S. Wants Controlled Escalation

Although Washington has conducted direct military operations, analysts generally believe its objective is:

- Deterrence
- Protection of allies
- Freedom of navigation

rather than another long-term Middle Eastern occupation.

---

## 5. The Strait of Hormuz Remains the Largest Global Risk

Approximately one-fifth of the world's oil supply normally passes through the Strait of Hormuz.

Any prolonged disruption could affect:

- Oil prices
- Inflation
- Shipping costs
- Global supply chains
- Financial markets

---

# Overall Summary

The conflict has progressed through three major phases:

## Phase 1 — June 2025

- Israel launches Operation Rising Lion.
- Iran retaliates with massive missile attacks.
- The United States joins with strikes on Iranian nuclear facilities.
- A temporary ceasefire ends the Twelve-Day War.

---

## Phase 2 — Late 2025 to Early 2026

- Military rebuilding
- Failed diplomacy
- Nuclear negotiations collapse
- Increased sanctions
- Regional military buildup

---

## Phase 3 — February 2026 to Present

- Renewed coordinated U.S.–Israeli strikes
- Iranian retaliation across the Middle East
- Maritime conflict around the Strait of Hormuz
- Continuing air and missile warfare
- Ongoing risk of wider regional escalation

---

# Key Takeaway

As of **19 July 2026**, the conflict remains active.

While none of the major actors appears to seek a full-scale ground invasion of Iran, all sides continue using air power, missiles, drones, cyber operations, and regional proxies. The greatest strategic concern remains that further escalation could disrupt global energy markets and draw additional regional actors into the conflict.
